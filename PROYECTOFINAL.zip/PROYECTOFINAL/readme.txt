primero baja todos los dockers que tengas 
subir archivo: docker compose up -d
si no funciona con ese subelo con este comando: docker compose down -v && docker compose up --build
puertos:
http://localhost:5000/
http://localhost:8082/
usuario:flaskuser
contraseña: flaskpass
