from flask import Flask, render_template, request, redirect, url_for
from models import db, Player, Tournament
from datetime import datetime
import os

app = Flask(__name__)

# Configuración de la base de datos
app.config["SQLALCHEMY_DATABASE_URI"] = (
    f"mysql+pymysql://{os.getenv('MYSQL_USER', 'user')}:{os.getenv('MYSQL_PASSWORD', 'password')}@mysql/{os.getenv('MYSQL_DATABASE', 'flaskdb')}"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

with app.app_context():
    db.create_all()

# Rutas para Jugadores
@app.route("/")
def index():
    players = Player.query.all()
    return render_template("index.html", players=players)

@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        name = request.form["name"]
        score = request.form["score"]
        game = request.form["game"]
        db.session.add(Player(name=name, score=int(score), game=game))
        db.session.commit()
        return redirect(url_for("index"))
    return render_template("form.html")

@app.route("/edit/<int:id>", methods=["GET", "POST"])
def edit(id):
    player = Player.query.get_or_404(id)
    if request.method == "POST":
        player.name = request.form["name"]
        player.score = int(request.form["score"])
        player.game = request.form["game"]
        db.session.commit()
        return redirect(url_for("index"))
    return render_template("form.html", player=player)

@app.route("/delete/<int:id>")
def delete(id):
    player = Player.query.get_or_404(id)
    db.session.delete(player)
    db.session.commit()
    return redirect(url_for("index"))

# Rutas para Torneos
@app.route("/tournaments")
def tournaments():
    tournaments = Tournament.query.all()
    return render_template("tournaments.html", tournaments=tournaments)

@app.route("/add_tournament", methods=["GET", "POST"])
def add_tournament():
    if request.method == "POST":
        name = request.form["name"]
        game = request.form["game"]
        date = datetime.strptime(request.form["date"], '%Y-%m-%d').date()
        participants = int(request.form["participants"])
        db.session.add(Tournament(
            name=name,
            game=game,
            date=date,
            participants=participants
        ))
        db.session.commit()
        return redirect(url_for("tournaments"))
    return render_template("tournament_form.html")

@app.route("/edit_tournament/<int:id>", methods=["GET", "POST"])
def edit_tournament(id):
    tournament = Tournament.query.get_or_404(id)
    if request.method == "POST":
        tournament.name = request.form["name"]
        tournament.game = request.form["game"]
        tournament.date = datetime.strptime(request.form["date"], '%Y-%m-%d').date()
        tournament.participants = int(request.form["participants"])
        db.session.commit()
        return redirect(url_for("tournaments"))
    return render_template("tournament_form.html", tournament=tournament)

@app.route("/delete_tournament/<int:id>")
def delete_tournament(id):
    tournament = Tournament.query.get_or_404(id)
    db.session.delete(tournament)
    db.session.commit()
    return redirect(url_for("tournaments"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)