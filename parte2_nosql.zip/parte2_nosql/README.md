# Ejecutar el contenedor

```bash
docker-compose up -d --build
docker exec -it apache bash
cd /var/www/html
composer install

```
