<?php
// Mostrar errores durante el desarrollo
ini_set('display_errors', 1);
error_reporting(E_ALL);

require '../db.php';

if (!isset($_GET['codigo'])) {
    header("Location: index.php");
    exit();
}

$codigo = $_GET['codigo'];
$torneo = $coleccion_torneos->findOne(['codigo' => $codigo]);

if (!$torneo) {
    echo "<p style='text-align:center; margin-top:2rem;'>No se encontró el torneo con código: $codigo</p>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $coleccion_torneos->updateOne(
        ['codigo' => $codigo],
        ['$set' => [
            'nombre_torneo' => $_POST['nombre_torneo'],
            'juego' => $_POST['juego'],
            'fecha' => new MongoDB\BSON\UTCDateTime(strtotime($_POST['fecha']) * 1000),
            'participantes' => array_map('trim', explode(',', $_POST['participantes']))
        ]]
    );
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Editar Torneo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #6a11cb, #2575fc);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 2rem;
      color: #fff;
    }

    h1 {
      margin-bottom: 2rem;
      font-weight: 700;
      text-align: center;
      text-shadow: 0 0 8px rgba(0, 0, 0, 0.4);
    }

    form {
      background: rgba(255, 255, 255, 0.1);
      padding: 2.5rem;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 600px;
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.18);
    }

    .form-label {
      font-weight: 600;
      color: #e0e0e0;
      margin-bottom: 0.4rem;
    }

    .form-control {
      background: rgba(255, 255, 255, 0.2);
      border: none;
      border-radius: 8px;
      color: #fff;
      box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.15);
      transition: background-color 0.3s ease;
    }

    .form-control:focus {
      background: rgba(255, 255, 255, 0.4);
      color: #000;
      outline: none;
      box-shadow: 0 0 8px #2575fc;
    }

    .btn-primary {
      background: #2575fc;
      border: none;
      font-weight: 600;
      padding: 0.5rem 1.8rem;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(37, 117, 252, 0.6);
      transition: background-color 0.3s ease;
      color: #fff;
    }

    .btn-primary:hover {
      background: #6a11cb;
      box-shadow: 0 6px 20px rgba(106, 17, 203, 0.7);
      color: #fff;
    }

    .btn-secondary {
      background: transparent;
      border: 2px solid #e0e0e0;
      color: #e0e0e0;
      margin-left: 1rem;
      font-weight: 600;
      padding: 0.5rem 1.8rem;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .btn-secondary:hover {
      background: #e0e0e0;
      color: #2575fc;
      border-color: #2575fc;
    }

    .text-center {
      margin-top: 1.5rem;
      display: flex;
      justify-content: center;
    }
  </style>
</head>
<body>
  <form method="POST" novalidate>
    <h1>Editar Torneo</h1>
    <div class="mb-4">
      <label class="form-label" for="nombre_torneo">Nombre del Torneo</label>
      <input id="nombre_torneo" type="text" name="nombre_torneo" class="form-control" 
        value="<?= htmlspecialchars($torneo['nombre_torneo']) ?>" required />
    </div>
    <div class="mb-4">
      <label class="form-label" for="juego">Juego</label>
      <input id="juego" type="text" name="juego" class="form-control" 
        value="<?= htmlspecialchars($torneo['juego']) ?>" required />
    </div>
    <div class="mb-4">
      <label class="form-label" for="fecha">Fecha</label>
      <input id="fecha" type="date" name="fecha" class="form-control" 
        value="<?= $torneo['fecha']->toDateTime()->format('Y-m-d') ?>" required />
    </div>
    <div class="mb-4">
      <label class="form-label" for="participantes">Participantes (separados por coma)</label>
      <input id="participantes" type="text" name="participantes" class="form-control"
        value="<?= isset($torneo['participantes']) && is_array($torneo['participantes']) 
          ? htmlspecialchars(implode(',', $torneo['participantes'])) 
          : '' ?>" required />
    </div>
    <div class="text-center">
      <button type="submit" class="btn btn-primary">Actualizar</button>
      <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>
</body>
</html>
