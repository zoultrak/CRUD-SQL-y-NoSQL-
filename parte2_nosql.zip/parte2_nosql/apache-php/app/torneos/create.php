<?php
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nuevo = [
        'codigo' => $_POST['codigo'],
        'nombre_torneo' => $_POST['nombre_torneo'],
        'juego' => $_POST['juego'],
        'fecha' => new MongoDB\BSON\UTCDateTime(strtotime($_POST['fecha']) * 1000),
        'participantes' => array_map('trim', explode(',', $_POST['participantes']))
    ];
    $coleccion_torneos->insertOne($nuevo);
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Torneo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #000;
      color: #00ffff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 3rem;
      min-height: 100vh;
    }

    h1 {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      text-align: center;
      color: #00ffff;
      text-shadow:
        0 0 5px #00ffff,
        0 0 10px #00cccc,
        0 0 20px #00cccc;
    }

    form {
      max-width: 600px;
      width: 90%;
      padding: 2rem;
      background-color: #111;
      border-radius: 0.75rem;
      box-shadow:
        0 0 10px #00ffff,
        0 0 20px #00cccc;
      border: 1px solid #00ffff;
    }

    .form-label {
      font-weight: 600;
      color: #00ffff;
      text-shadow: 0 0 4px #00cccc;
    }

    .form-control {
      border-radius: 0.375rem;
      background-color: #000;
      color: #0ff;
      border: 1px solid #00cccc;
      box-shadow: inset 0 0 5px #00cccc;
    }

    .form-control:focus {
      background-color: #000;
      color: #fff;
      box-shadow: 0 0 10px #00e6e6;
      border-color: #00ffff;
    }

    .btn {
      padding: 0.5rem 1.5rem;
      border-radius: 0.375rem;
      font-weight: 600;
      transition: all 0.3s ease;
    }

    .btn-success {
      background-color: #00ff80;
      border-color: #00cc66;
      color: #000;
      box-shadow: 0 0 10px #00ff80, 0 0 20px #00cc66;
    }

    .btn-success:hover {
      background-color: #00cc66;
      color: #fff;
      box-shadow: 0 0 15px #00ff80;
    }

    .btn-secondary {
      background-color: #444;
      border-color: #666;
      color: #ccc;
      margin-left: 0.5rem;
      box-shadow: 0 0 10px #666;
    }

    .btn-secondary:hover {
      background-color: #666;
      color: #fff;
    }

    input[type="date"]::-webkit-calendar-picker-indicator {
      filter: invert(1);
    }

    .text-center {
      text-align: center;
      margin-top: 1.5rem;
    }

    a.btn {
      text-decoration: none;
    }
  </style>
</head>
<body>
  <h1>Agregar Torneo</h1>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Código</label>
      <input type="text" name="codigo" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nombre del Torneo</label>
      <input type="text" name="nombre_torneo" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Juego</label>
      <input type="text" name="juego" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Fecha</label>
      <input type="date" name="fecha" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Participantes (separados por coma)</label>
      <input type="text" name="participantes" class="form-control" required>
    </div>
    <div class="text-center">
      <button type="submit" class="btn btn-success">Guardar</button>
      <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>
</body>
</html>
