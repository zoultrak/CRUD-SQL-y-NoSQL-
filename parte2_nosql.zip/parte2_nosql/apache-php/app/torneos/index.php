<?php require '../db.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Lista de Torneos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #000;
      color: #0ff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding-top: 3rem;
      min-height: 100vh;
    }

    h1 {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      text-align: center;
      color: #00ffff;
      text-shadow:
        0 0 5px #00ffff,
        0 0 10px #00cccc,
        0 0 20px #00cccc;
    }

    .btn {
      font-weight: 600;
      border-radius: 0.375rem;
      padding: 0.4rem 1rem;
      transition: all 0.3s ease;
      box-shadow: 0 0 8px rgba(0, 255, 255, 0.3);
    }

    .btn-success {
      background-color: #00ff80;
      border-color: #00cc66;
      color: #000;
      box-shadow: 0 0 10px #00ff80, 0 0 20px #00cc66;
    }

    .btn-success:hover {
      background-color: #00cc66;
      color: #fff;
    }

    .btn-secondary {
      background-color: #444;
      border-color: #666;
      color: #ccc;
      box-shadow: 0 0 10px #666;
      margin-left: 0.5rem;
    }

    .btn-secondary:hover {
      background-color: #666;
      color: #fff;
    }

    .btn-warning {
      background-color: #ffff00;
      color: #000;
      border-color: #cccc00;
      box-shadow: 0 0 10px #ffff00;
    }

    .btn-warning:hover {
      background-color: #cccc00;
      color: #000;
    }

    .btn-danger {
      background-color: #ff4444;
      border-color: #cc0000;
      color: #fff;
      box-shadow: 0 0 10px #ff4444;
    }

    .btn-danger:hover {
      background-color: #cc0000;
      color: #fff;
    }

    .table {
      background-color: #111;
      border-radius: 0.5rem;
      overflow: hidden;
      box-shadow: 0 0 20px #00ffff;
      color: #0ff;
    }

    table th {
      background-color: #222;
      color: #00ffff;
      font-weight: 700;
      text-align: center;
      text-shadow: 0 0 5px #00cccc;
    }

    table td {
      vertical-align: middle;
      text-align: center;
      color: #ccf;
    }

    .container {
      max-width: 1000px;
      margin: 0 auto;
    }

    .mb-4 a {
      margin: 0.3rem;
    }

    a.btn {
      text-decoration: none;
    }
  </style>
</head>
<body class="container">
  <h1>Torneos</h1>
  <div class="mb-4 text-center">
    <a href="create.php" class="btn btn-success mb-3">➕ Agregar Torneo</a>
    <a href="../index.php" class="btn btn-secondary mb-3">⬅️ Volver al menú</a>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Código</th>
        <th>Nombre</th>
        <th>Juego</th>
        <th>Fecha</th>
        <th>Participantes</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $torneos = $coleccion_torneos->find();
        foreach ($torneos as $t) {
          echo "<tr>
                  <td>{$t['codigo']}</td>
                  <td>{$t['nombre_torneo']}</td>
                  <td>{$t['juego']}</td>
                  <td>" . $t['fecha']->toDateTime()->format('Y-m-d') . "</td>
                  <td>" . implode(', ', (array) $t['participantes']->getArrayCopy()) . "</td>
                  <td>
                    <a href='update.php?codigo={$t['codigo']}' class='btn btn-warning btn-sm'>Editar</a>
                    <a href='delete.php?codigo={$t['codigo']}' class='btn btn-danger btn-sm'>Eliminar</a>
                  </td>
                </tr>";
        }
      ?>
    </tbody>
  </table>
</body>
</html>
