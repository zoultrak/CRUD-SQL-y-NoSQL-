<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Menú principal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color:rgb(15, 14, 14);
      color: #fff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 3rem;
      user-select: none;
    }

    h1 {
      font-size: 3rem;
      margin-bottom: 3rem;
      text-align: center;
      color:rgb(35, 5, 64);
      text-shadow:
        0 0 5px #8a2be2,
        0 0 10px #8a2be2,
        0 0 20px #7b68ee,
        0 0 40px #7b68ee,
        0 0 80px #7b68ee;
    }

    .list-group {
      max-width: 420px;
      width: 90vw;
      border-radius: 10px;
      overflow: hidden;
      box-shadow:
        0 0 10px #8a2be2,
        0 0 20px #7b68ee,
        0 0 30px #5f4b8b;
      background: #111111;
      border: 1px solid #8a2be2;
    }

    .list-group-item {
      background: transparent;
      border: none;
      padding: 1.2rem 2rem;
      transition: all 0.3s ease;
      position: relative;
      cursor: pointer;
      color: #9b59b6;
      font-weight: 600;
      text-shadow:
        0 0 3px #9b59b6,
        0 0 8px #8a2be2;
    }

    .list-group-item:hover {
      color: #fff;
      background: #5f4b8b;
      text-shadow:
        0 0 5px #fff,
        0 0 15px #8a2be2,
        0 0 20px #7b68ee;
      box-shadow:
        inset 0 0 10px #8a2be2,
        0 0 15px #8a2be2;
      border-radius: 8px;
    }

    .list-group-item a {
      color: inherit;
      text-decoration: none;
      display: block;
    }

    .list-group-item a:hover {
      text-decoration: none;
      color: #e0e0ff;
    }
  </style>
</head>
<body class="container">
  <h1>Proyecto final parte 2 <br> Base de datos Games</h1>
  <ul class="list-group">
    <li class="list-group-item"><a href="jugadores/index.php">🔹 Gestión de Jugadores</a></li>
    <li class="list-group-item"><a href="torneos/index.php">🔸 Gestión de Torneos</a></li>
  </ul>
</body>
</html>
