<?php
require __DIR__ . '/vendor/autoload.php';

$cliente = new MongoDB\Client("mongodb://mongo:27017");

// Usamos la base de datos `games`
$bd = $cliente->games;

// Acceso a las colecciones individuales
$coleccion_jugadores = $bd->jugadores;
$coleccion_torneos = $bd->torneos;  // para la colección 2
?>
