<?php
require '../db.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];
$jugador = $coleccion_jugadores->findOne(['id' => $id]);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $coleccion_jugadores->updateOne(
        ['id' => $id],
        ['$set' => [
            'nombre' => $_POST['nombre'],
            'apodo' => $_POST['apodo'],
            'nombre_juego' => $_POST['nombre_juego']
        ]]
    );
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Editar Jugador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #6a11cb, #2575fc);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 2rem;
      color: #fff;
    }

    h1 {
      margin-bottom: 2rem;
      font-weight: 700;
      text-align: center;
      text-shadow: 0 0 8px rgba(0, 0, 0, 0.4);
    }

    form {
      background: rgba(255, 255, 255, 0.1);
      padding: 2.5rem;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 600px;
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.18);
    }

    label.form-label {
      font-weight: 600;
      color: #e0e0e0;
      margin-bottom: 0.4rem;
      display: block;
    }

    input.form-control {
      background: rgba(255, 255, 255, 0.2);
      border: none;
      border-radius: 8px;
      color: #fff;
      box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.15);
      transition: background-color 0.3s ease, color 0.3s ease;
      width: 100%;
      padding: 0.5rem 0.75rem;
      font-size: 1rem;
    }

    input.form-control:focus {
      background: rgba(255, 255, 255, 0.4);
      color: #000;
      outline: none;
      box-shadow: 0 0 8px #2575fc;
    }

    .btn-primary {
      background: #2575fc;
      border: none;
      font-weight: 600;
      padding: 0.5rem 1.8rem;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(37, 117, 252, 0.6);
      transition: background-color 0.3s ease;
      color: #fff;
      cursor: pointer;
    }

    .btn-primary:hover,
    .btn-primary:focus {
      background: #6a11cb;
      box-shadow: 0 6px 20px rgba(106, 17, 203, 0.7);
      color: #fff;
    }

    .btn-secondary {
      background: transparent;
      border: 2px solid #e0e0e0;
      color: #e0e0e0;
      margin-left: 1rem;
      font-weight: 600;
      padding: 0.5rem 1.8rem;
      border-radius: 8px;
      transition: all 0.3s ease;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      text-align: center;
    }

    .btn-secondary:hover,
    .btn-secondary:focus {
      background: #e0e0e0;
      color: #2575fc;
      border-color: #2575fc;
      text-decoration: none;
    }

    .text-center {
      margin-top: 1.5rem;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 1rem;
    }
  </style>
</head>
<body>
  <form method="POST" novalidate>
    <h1>Editar Jugador</h1>
    <div class="mb-4">
      <label class="form-label" for="nombre">Nombre</label>
      <input id="nombre" type="text" name="nombre" class="form-control" 
        value="<?= htmlspecialchars($jugador['nombre'] ?? '') ?>" required />
    </div>
    <div class="mb-4">
      <label class="form-label" for="apodo">Apodo</label>
      <input id="apodo" type="text" name="apodo" class="form-control" 
        value="<?= htmlspecialchars($jugador['apodo'] ?? '') ?>" required />
    </div>
    <div class="mb-4">
      <label class="form-label" for="nombre_juego">Nombre del Juego</label>
      <input id="nombre_juego" type="text" name="nombre_juego" class="form-control" 
        value="<?= htmlspecialchars($jugador['nombre_juego'] ?? '') ?>" required />
    </div>
    <div class="text-center">
      <button type="submit" class="btn btn-primary">Actualizar</button>
      <a href="index.php" class="btn btn-secondary" role="button" tabindex="0">Cancelar</a>
    </div>
  </form>
</body>
</html>
