<?php
require '../db.php';

if (isset($_GET['codigo'])) {
    $codigo = $_GET['codigo'];
    $coleccion_jugadores->deleteOne(['codigo' => $codigo]);
}
header("Location: index.php");
exit();
