<?php
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nuevo = [
        'id' => (int)$_POST['id'],
        'nombre' => $_POST['nombre'],
        'apodo' => $_POST['apodo'],
        'nombre_juego' => $_POST['nombre_juego']
    ];
    $coleccion_jugadores->insertOne($nuevo);
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Jugador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #000;
      color: #00ffff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 3rem;
      min-height: 100vh;
    }

    h1 {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      text-align: center;
      color: #00ffff;
      text-shadow:
        0 0 5px #00ffff,
        0 0 10px #00cccc,
        0 0 20px #00cccc;
    }

    form {
      max-width: 600px;
      width: 90%;
      padding: 2rem;
      background-color: #111;
      border-radius: 0.75rem;
      box-shadow:
        0 0 10px #00ffff,
        0 0 20px #00cccc;
      border: 1px solid #00ffff;
    }

    .form-label {
      font-weight: 600;
      color: #00ffff;
      text-shadow: 0 0 4px #00cccc;
    }

    .form-control {
      border-radius: 0.375rem;
      background-color: #000;
      color: #0ff;
      border: 1px solid #00cccc;
      box-shadow: inset 0 0 5px #00cccc;
    }

    .form-control:focus {
      background-color: #000;
      color: #fff;
      box-shadow: 0 0 10px #00e6e6;
      border-color: #00ffff;
    }

    .btn {
      padding: 0.5rem 1.5rem;
      border-radius: 0.375rem;
      font-weight: 600;
      transition: all 0.3s ease;
    }

    .btn-success {
      background-color: #00ff80;
      border-color: #00cc66;
      color: #000;
      box-shadow: 0 0 10px #00ff80, 0 0 20px #00cc66;
    }

    .btn-success:hover {
      background-color: #00cc66;
      color: #fff;
    }

    .btn-secondary {
      background-color: #444;
      border-color: #666;
      color: #ccc;
      margin-left: 0.5rem;
      box-shadow: 0 0 10px #666;
    }

    .btn-secondary:hover {
      background-color: #666;
      color: #fff;
    }

    .text-center {
      text-align: center;
      margin-top: 1.5rem;
    }

    a.btn {
      text-decoration: none;
    }
  </style>
</head>
<body>
  <h1>Agregar Jugador</h1>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">ID</label>
      <input type="number" name="id" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nombre</label>
      <input type="text" name="nombre" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Apodo</label>
      <input type="text" name="apodo" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nombre del Juego</label>
      <input type="text" name="nombre_juego" class="form-control" required>
    </div>
    <div class="text-center">
      <button type="submit" class="btn btn-success">Guardar</button>
      <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>
</body>
</html>
