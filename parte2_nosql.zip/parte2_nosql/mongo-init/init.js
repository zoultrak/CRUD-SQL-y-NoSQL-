db = db.getSiblingDB('jugadores');

db.estudiantes.insertMany([
  {
    id: 1,
    nombre: 'juan searez',
    apodo: 'lovewave',
    nombre_juego: new Date('2025-11-01')
  },

]);

